# Dataset files

## Original dataset
The project uses the 1,025-row, 14-column `heart.csv` dataset documented in the report.
The reproducibility source used by the notebook is:

https://raw.githubusercontent.com/GehadGad/Heart-disease-dataset/main/heart.csv

Place the downloaded file at:

`data/heart.csv`

If it is absent, `SIT720_11_1HD_Execution.py` downloads it automatically from the same documented source.

## Deduplicated dataset

Run the main script once. It creates:

`data/heart_deduplicated.csv`

This file contains the 302 unique rows obtained by exact `drop_duplicates()` before the Part 2 train/test split.
